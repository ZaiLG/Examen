--------------------------------------------------------------------------
-- 1.-
--------------------------------------------------------------------------

create procedure Tbl_Recuperacion_Alta
@AnioMes char(6),
@ClaCliente int,
@ImpRecuperacion money

as

/*
*******************************************************
Descripcion:Proceso para dar de alta una recuperacion
*******************************************************
*/

/*Declaracion de variables*/
declare @NumeroCliente int

/*declaracion de constantes*/
declare @EnteroCero smallint,
		@CharVacio	char(1)
		
/*Asignacion de constantes*/
select	@EnteroCero = 0,
		@CharVacio = ''

if (@AnioMes = @CharVacio) begin
	select 'El valor del a�o/mes es incorrecto'
	return
end

select @NumeroCliente = @EnteroCero

select @NumeroCliente = ClaCliente
from Dim_Cliente noholdlock
where ClaCliente = @ClaCliente

select @NumeroCliente = ISNULL(@NumeroCliente,@EnteroCero)

select @NumeroCliente

if (@NumeroCliente = @EnteroCero) begin
	select 'El n�mero de cliente es inexistente.'
	return
end

if (@AnioMes = @CharVacio) begin
	select 'El valor del a�o/mes es incorrecto.'
	return
end

if (@ImpRecuperacion <= @EnteroCero) begin
	select 'El monto de recuperaci�n debe de ser mayor a cero.'
	return
end

INSERT INTO Tbl_Recuperacion
       (AnioMes,	ClaCliente,		ImpRecuperacion)
VALUES (@AnioMes,	@ClaCliente,	@ImpRecuperacion)



--------------------------------------------------------------------------
-- 2.-
--------------------------------------------------------------------------

declare @AgrupadorCliente int

select @AgrupadorCliente = 543

delete  Dim_Cliente
from Dim_Cliente
inner join Dim_AgrupadorCliente
on Dim_AgrupadorCliente.ClaAgrupadorCliente = Dim_Cliente.ClaAgrupadorCliente
and Dim_AgrupadorCliente.ClaAgrupadorCliente = @AgrupadorCliente


--------------------------------------------------------------------------
-- 3.-
--------------------------------------------------------------------------

declare @Anio char(4),
		@MoneyCero money

select	@Anio = '2020',
		@MoneyCero = 0.00

create table #TmpTotalClientes (
ClaCliente int, 
Anio char(4),
ImpRecuperacionTotal money, 
ImpObjetivoTotal money)

create table #TmpAuxiliar (
ClaCliente int, 
Monto money)

insert into #TmpTotalClientes (ClaCliente, Anio, ImpRecuperacionTotal, ImpObjetivoTotal)
select ClaCliente,	@Anio, @MoneyCero,	@MoneyCero
	from Dim_Cliente noholdlock

insert into #TmpAuxiliar (ClaCliente,Monto)
select ClaCliente,	sum(ImpRecuperacion)
from Tbl_Recuperacion noholdlock
where substring(AnioMes,1,4) = @Anio
group by ClaCliente

update #TmpTotalClientes
set ImpRecuperacionTotal = Monto
from #TmpTotalClientes 
inner join #TmpAuxiliar 
on #TmpTotalClientes.ClaCliente = #TmpAuxiliar.ClaCliente

delete #TmpAuxiliar

insert into #TmpAuxiliar (ClaCliente,Monto)
select ClaCliente,	sum(ImpObjetivo)
from Tbl_Objetivo noholdlock
where substring(AnioMes,1,4) = @Anio
group by ClaCliente

update #TmpTotalClientes
set ImpObjetivoTotal = Monto
from #TmpTotalClientes 
inner join #TmpAuxiliar 
on #TmpTotalClientes.ClaCliente = #TmpAuxiliar.ClaCliente

delete #TmpAuxiliar

select ClaCliente, Anio, ImpRecuperacionTotal, ImpObjetivoTotal
from #TmpTotalClientes noholdlock

drop table #TmpTotalClientes, #TmpAuxiliar

--------------------------------------------------------------------------
-- 4.-
--------------------------------------------------------------------------

/*variables*/
declare @ImpRecuperacion money,
		@ImpBonificaciones money,
		@ImpObjetivo money,
		@PorcImpRecuperacion money,
		@Anio char(4),
		@Mes char(2),
		@EnteroAuxMes smallint,
		@CharAuxMes char(2),
		@EnteroAuxAnio smallint,
		@CharAuxAnio char(4)

/*constantes*/
declare	@Maximo int,
		@Minimo int,
		@EnteroCero smallint,
		@EnteroUno smallint,
		@EnteroDiez smallint,
		@EnteroDoce smallint,
		@MoneyCero money,
		@CharVacio char(1),
		@CharCero char(1)

/*asignacion de constantes*/
select	@EnteroCero = 0,
		@EnteroUno	= 1,
		@EnteroDiez	= 10,
		@EnteroDoce	= 12,
		@MoneyCero	= 0.00,
		@CharVacio	= '',
		@CharCero	= '0'

create table #Tmp_Tbl_Recuperacion(
	Consecutivo int identity,
	AnioMes char(6),
	ImpRecuperacion money,
	Anio char(4),
	Mes char(2),
	PorcImpRecuperacion money
)

create table #Tmp_Tbl_Objetivo(
	Consecutivo int identity,
	AnioMes char(6),
	ImpObjetivo money,
	Anio char(4),
	Mes char(2)
)

create table #Tmp_Tbl_Bonificacion(
	Consecutivo int identity,
	AnioMes char(6),
	ImpBonificaciones money,
	Anio char(4),
	Mes char(2)
)

insert into #Tmp_Tbl_Recuperacion (AnioMes,ImpRecuperacion,Anio,Mes,PorcImpRecuperacion)
select AnioMes,sum(ImpRecuperacion),substring(AnioMes,1,4),substring(AnioMes,5,2),@MoneyCero
from Tbl_Recuperacion
group by AnioMes

insert into #Tmp_Tbl_Objetivo (AnioMes,ImpObjetivo,Anio,Mes)
select AnioMes,sum(ImpObjetivo),substring(AnioMes,1,4),substring(AnioMes,5,2)
from Tbl_Objetivo
group by AnioMes

insert into #Tmp_Tbl_Bonificacion (AnioMes,ImpBonificaciones,Anio,Mes)
select AnioMes,sum(ImpBonificaciones),substring(AnioMes,1,4),substring(AnioMes,5,2)
from Tbl_Bonificacion
group by AnioMes

select	@Minimo = min(Consecutivo)
	from #Tmp_Tbl_Recuperacion
	
select	@Maximo	= max(Consecutivo)
	from #Tmp_Tbl_Recuperacion

while(@Minimo <= @Maximo)begin

	select	@ImpRecuperacion = @MoneyCero,
			@ImpBonificaciones = @MoneyCero,
			@ImpObjetivo = @MoneyCero,
			@PorcImpRecuperacion = @MoneyCero,
			@Anio = @CharVacio,
			@Mes = @CharVacio

	select	@ImpRecuperacion = ImpRecuperacion,
			@Anio = Anio,
			@Mes = Mes
	from #Tmp_Tbl_Recuperacion
	where Consecutivo = @Minimo

	select	@ImpBonificaciones = ImpBonificaciones
		from #Tmp_Tbl_Bonificacion
		where	Anio = @Anio
			and Mes = @Mes

	/*validacion del mes/a�o*/
	select	@CharAuxMes = @CharVacio,
			@CharAuxAnio = @CharVacio

	select	@EnteroAuxMes = convert(int,@Mes),
			@EnteroAuxAnio = convert(int,@Anio)

	if @EnteroAuxMes > @EnteroUno begin
		select @EnteroAuxMes = @EnteroAuxMes - @EnteroUno
	end else if @EnteroAuxMes = @EnteroUno begin
		select @EnteroAuxMes = @EnteroDoce
		select @EnteroAuxAnio = @EnteroAuxAnio - @EnteroUno
	end

	if @EnteroAuxMes < @EnteroDiez begin
		select @CharAuxMes = @CharCero + convert(varchar,@EnteroAuxMes)
	end else begin
		select @CharAuxMes = convert(varchar,@EnteroAuxMes)
	end

	select @CharAuxAnio = convert(varchar,@EnteroAuxAnio)
	   	 
	select	@ImpObjetivo = ImpObjetivo
		from #Tmp_Tbl_Objetivo
		where	Anio = @CharAuxAnio
			and Mes = @CharAuxMes

	select @PorcImpRecuperacion = isnull(@ImpRecuperacion,@MoneyCero) / (isnull(@ImpObjetivo,@MoneyCero)-isnull(@ImpBonificaciones,@MoneyCero))

		update #Tmp_Tbl_Recuperacion 
		set PorcImpRecuperacion = @PorcImpRecuperacion
		where Consecutivo = @Minimo
	
	select @Minimo = @Minimo + @EnteroUno
end

select 	Anio, Mes, ImpRecuperacion,	PorcImpRecuperacion
from #Tmp_Tbl_Recuperacion

drop table #Tmp_Tbl_Recuperacion,#Tmp_Tbl_Objetivo,#Tmp_Tbl_Bonificacion


--------------------------------------------------------------------------
-- 7.-
--------------------------------------------------------------------------
declare @XML1 xml   (Ventas.EsquemaFacturas)


